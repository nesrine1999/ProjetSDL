#ifndef STRUCT_H_
#define STRUCT_H_

typedef struct pos
{
	int x;
	int y;
}pos;

typedef struct level
{
	int nbr_level;
}level;

typedef struct AABB
{	
	int x;
	int y;
	int w;
	int h;
}AABB;
#endif /* FONCTIONS_H_ */
