/*
 * Pendu - Jeu du pendu.
 * Copyright (C) 2007  HECHT Franck - franhec@gmail.com
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef H_HF_GUI_150820071752
#define H_HF_GUI_150820071752


#include "game.h"
#include <SDL/SDL.h>


/*
 * Constantes pour le type d'ecran en cours dans le programme.
 */
typedef enum
{
   SCREEN_TYPE_GAME,
   SCREEN_TYPE_NEW_WORD,
   SCREEN_TYPE_CONFIRM_EXIT,

   NB_SCREEN_TYPE
}
screen_type;


/*
 * Constantes pour le status courant du programme.
 */
typedef enum
{
   GAME_STATUS_NEED_WORD,
   GAME_STATUS_IN_PROGRESS,
   GAME_STATUS_GAINED,
   GAME_STATUS_LOST,

   NB_GAME_STATUS
}
game_status;


/*
 * Constantes pour le type de l'information du bas.
 */
typedef enum
{
   INFOS_TYPE_SINGLE,   /* Information sur la touche Echap. */
   INFOS_TYPE_DOUBLE,   /* Information sur la touche Echap et Entree. */

   NB_INFOS_TYPE
}
infos_type;


/*
 * Structure de la fenetre du jeu
 */
typedef struct
{
   /* Type de l'ecran en cours d'affichage. */
   screen_type type;

   /* Status courant du jeu. */
   game_status status;

   /* Ecran princpal avec son rectangle. */
   SDL_Surface * p_screen;
   SDL_Rect screen_rect;
   SDL_bool screen_need_update;

   /* Image de fond. */
   SDL_Surface * p_background;

   /* Zone d'affichage du mot a trouver. */
   SDL_Surface * p_word;
   SDL_Rect word_rect;
   SDL_bool word_need_update;

   /* Zone d'affichage du pendu. */
   SDL_Surface * p_hung;
   SDL_Rect hung_rect;
   SDL_bool hung_need_update;

   /* Zones d'affichage des informations. */
   SDL_Surface * p_top_infos;
   SDL_Surface * p_bottom_infos;
   SDL_Rect top_infos_rect;
   SDL_Rect bottom_infos_rect;
   SDL_bool infos_need_update;
   infos_type infos_type;
}
pendu_screen;


/*
 * Prototypes des fonctions publiques.
 */
pendu_screen * create_window (void);
void destroy_window (pendu_screen ** p_self);
void draw (pendu_screen * p_self, word_t * p_word);


#endif

