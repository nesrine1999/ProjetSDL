

#ifndef H_HF_EVENTS_150820071752
#define H_HF_EVENTS_150820071752

#include <SDL/SDL.h>
#include "gui.h"


/*
 * Prototypes des fonctions publiques.
 */
SDL_bool keyboard_events (SDL_Event * p_event,
                          pendu_screen * p_self,
                          word_t * p_word);


#endif

