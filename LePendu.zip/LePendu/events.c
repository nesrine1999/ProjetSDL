#include "events.h"
#include "game.h"


SDL_bool keyboard_events (SDL_Event * p_event,
                          pendu_screen * p_self,
                          word_t * p_word)
{
   SDL_bool quit = SDL_FALSE;


   if (p_event != NULL && p_self != NULL)
   {
      if (p_event->type == SDL_KEYUP)
      {
         switch (p_event->key.keysym.sym)
         {
            
            case SDLK_ESCAPE:
            {
               quit = SDL_TRUE;
            }
            break;

            
            case SDLK_RETURN:
            {
               if (p_self->status == GAME_STATUS_GAINED ||
                   p_self->status == GAME_STATUS_LOST)
               {
                  p_self->status       = GAME_STATUS_NEED_WORD;
                  p_self->infos_type   = INFOS_TYPE_SINGLE;

                  p_self->hung_need_update   = SDL_TRUE;
                  p_self->screen_need_update = SDL_TRUE;
                  p_self->word_need_update   = SDL_TRUE;
                  p_self->infos_need_update  = SDL_TRUE;
               }
            }
            break;

           
            default:
            {
               if (p_self->status == GAME_STATUS_IN_PROGRESS)
               {
                  if (p_event->key.keysym.sym >= SDLK_a &&
                      p_event->key.keysym.sym <= SDLK_z) 
                  {
                     if (find_char (p_word, p_event->key.keysym.sym))
                     {
                        if (p_word->count <= 0)
                        {
                           p_self->status       = GAME_STATUS_GAINED;
                           p_self->infos_type   = INFOS_TYPE_DOUBLE;

                           p_self->infos_need_update = SDL_TRUE;
                        }

                        p_self->word_need_update = SDL_TRUE;
                     }
                     else
                     {
                        if (p_word->nb_tests >= NB_TEST)
                        {
                           p_self->status       = GAME_STATUS_LOST;
                           p_self->infos_type   = INFOS_TYPE_DOUBLE;

                           p_self->infos_need_update = SDL_TRUE;
                        }
                     }

                     p_self->hung_need_update   = SDL_TRUE;
                     p_self->screen_need_update = SDL_TRUE;
                  }
               }
            }
            break;
         }
      }
   }


   return quit;
}

