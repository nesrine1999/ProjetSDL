


#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>

#include "game.h"
#include "gui.h"
#include "events.h"
#include "pendu.h"
int pendu()
{
   SDL_bool          quit     = SDL_FALSE;
   SDL_Event         event;
   pendu_screen   *  p_screen = NULL;
   word_t         *  p_word   = NULL;


   if (SDL_Init (SDL_INIT_VIDEO) >= 0)
   {
      atexit (SDL_Quit);


      
      p_screen = create_window ();

      if (p_screen != NULL)
      {
         SDL_ShowCursor (0);

         while (! quit)
         {
            
            if (p_screen->status == GAME_STATUS_NEED_WORD)
            {
               char * s_word = get_word (get_word_pos (), DICTIONARY);

               if (s_word != NULL)
               {
                  if (p_word != NULL)
                  {
                     destroy_word (& p_word);
                  }

                  p_word = make_word (s_word);
                  free (s_word);
                  p_screen->status = GAME_STATUS_IN_PROGRESS;
               }
            }


           
            if (p_screen->screen_need_update)
            {
               draw (p_screen, p_word);
            }


            
            if (SDL_WaitEvent (& event))
            {
               if (event.type == SDL_QUIT)
               {
                  quit = SDL_TRUE;
               }
               else
               {
                  quit = keyboard_events (& event, p_screen, p_word);
               }
            }
         }


         
         destroy_window (& p_screen);
         destroy_word   (& p_word);
         TTF_Quit       ();
      }
   }


   return EXIT_SUCCESS;
}

