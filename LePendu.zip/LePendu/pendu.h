#ifndef PENDU_H_INCLUDED
#define PENDU_H_INCLUDED
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_image.h> 
int pendu();
#endif // PENDU_H_INCLUDED
