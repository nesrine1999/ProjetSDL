#include "game.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <ctype.h>



int get_word_pos (void)
{
   srand (time (NULL));
   return (int)(rand() / (double)RAND_MAX * (NB_WORD - 1));
}



char * get_word (int word_pos, const char * dictionary)
{
   char * word = NULL;
   
   
   if (dictionary != NULL)
   {
      FILE * fp = fopen (dictionary, "r");
      
      if (fp != NULL)
      {
         int count = 0;
         char buf [MAX_LEN];
         
         
         while (fgets (buf, sizeof buf, fp) != NULL)
         {
            
            if (count == word_pos)
            {
               
               {
                  char * p = strchr (buf, '\n');

                  if (p != NULL)
                  {
                     *p = 0;
                  }
               }
               word = malloc (strlen (buf) + 1);
               
               if (word != NULL)
               {
                  strcpy (word, buf);
               }
               else
               {
                  
                  fprintf (
                     stderr,
                     "--> Erreur: Impossible d'allouer l'espace pour le mot !"
                  );
               }
               
               break;
            }
            
            count++;
         }
         
         
         fclose (fp);
      }
      else
      {
         fprintf (
            stderr,
            "--> Erreur: Impossible d'ouvrir le fichier %s !\n",
            dictionary
         );
      }
   }
   
   
   return word;
}



void destroy_word (word_t ** self)
{
   if (self != NULL && *self != NULL)
   {
      if ((* self)->word_to_find != NULL)
         free ((* self)->word_to_find);

      if ((* self)->word != NULL)
         free ((* self)->word);

     free (* self);
      *self = NULL;
   }
}



word_t * make_word (const char * word)
{
   word_t * self = NULL;


   if (word != NULL)
   {
      self = malloc (sizeof (* self));

      if (self != NULL)
      {
         memset (self, 0, sizeof (self));

         self->nb_char        = strlen (word);
         self->count          = self->nb_char;
         self->nb_tests       = 0;
         self->word           = malloc (self->nb_char + 1);
         self->word_to_find   = malloc (self->nb_char + 1);

         if (self->word != NULL && self->word_to_find != NULL)
         {
            strcpy      (self->word_to_find, word);
            memset      (self->word, INVISIBLE_CHAR, self->nb_char);
            self->word  [self->nb_char] = 0;
         }
         else
         {
            
            destroy_word (& self);
         }
      }
   }


   return self;
}



int find_char (word_t * self, const char c)
{
   int ret = 0;


   if (self != NULL)
   {
      size_t i = 0;
      char c2 = toupper (c);


      if (strchr (self->word_to_find, c2) != NULL)
      {
         for (i = 0; i < self->nb_char; i++)
         {
            
            if (self->word_to_find[i] == c2 && self->word[i] == INVISIBLE_CHAR)
            {
               self->word[i] = c2;
               self->count--;

               ret = 1;
            }
         }
      }
      else
      {
         self->nb_tests++;
      }
   }


   return ret;
}

