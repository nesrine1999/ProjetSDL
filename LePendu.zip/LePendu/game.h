


#ifndef H_HF_GAME_150820071752
#define H_HF_GAME_150820071752


#include <stdlib.h>
#include <stdio.h>


#define NB_TEST         12          /* Nombre d'essais pour trouver le mot.   */
#define NB_WORD         331612      /* Nombre de mots dans le dictionnaire.   */
#define MAX_LEN         50          /* Taille maximum d'un mot.               */
#define DICTIONARY      "dico.txt"  /* Dictionnaire par defaut.               */
#define INVISIBLE_CHAR  '-'         /* Caractere non trouve.                  */



typedef struct
{
   
   size_t nb_char;
   
   size_t count;

   
   size_t nb_tests;

   
   char * word;
   
   
   char * word_to_find;
}
word_t;



 
int      get_word_pos   (void);
char *   get_word       (int word_pos, const char * dictionary);
void     destroy_word   (word_t ** self);
word_t * make_word      (const char * word);
int      find_char      (word_t * self, const char c);


#endif

