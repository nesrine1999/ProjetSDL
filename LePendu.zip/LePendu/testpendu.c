#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>

#include "game.h"
#include "gui.h"
#include "events.h"
#include "pendu.h"
int main()
{
pendu();
}
