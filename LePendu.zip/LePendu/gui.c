


#include "gui.h"

#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_image.h>



#define SCREEN_W        640
#define SCREEN_H        480
#define BORDER_MARGIN   70
#define SCREEN_TITLE    "Donner un mot"
#define SINGLE_INFOS    "Quitter: Echap"
#define DOUBLE_INFOS    "Contiuner: Entree - Quitter: Echap"
#define GAME_TXT_R_VAL  255
#define GAME_TXT_G_VAL  255
#define GAME_TXT_B_VAL  255
#define INFO_TXT_R_VAL  125
#define INFO_TXT_G_VAL  65
#define INFO_TXT_B_VAL  10
#define BACKGROUND      "images/background.jpg"
#define TABLE_FONT      "fonts/table.ttf"
#define INFOS_FONT      "fonts/infos.ttf"
#define WORD_FONT_SIZE  16
#define INFO_TITLE_SIZE 22
#define INFO_SIZE       18
#define HUNG_FILENAME   "images/pendu-%d.png"
#define GAINED_FILENAME "images/gained.png"
#define LOST_FILENAME   "images/lost.png"
#define LETTERS_SPACING 5


/*
 * Fonction privee de rendu de texte.
 */
static SDL_Surface * make_text (const char * text,
                                const char * font_name,
                                int font_size,
                                SDL_Color * color)
{
   SDL_Surface *  p_text   = NULL;
   TTF_Font    *  p_font   = NULL;


   if (! TTF_WasInit () && TTF_Init () == -1)
   {
       printf ("TTF_Init: %s\n", TTF_GetError ());
       exit (EXIT_FAILURE);
   }


   p_font = TTF_OpenFont (font_name, font_size);

   if (p_font != NULL)
   {
      p_text = TTF_RenderText_Blended (p_font, text, *color);
      TTF_CloseFont (p_font);
   }
   else
   {
      fprintf (stderr, "%s\n", SDL_GetError ());
   }


   return p_text;
}



static void clear_screen (SDL_Surface * screen)
{
   int i = 0;


   if (SDL_LockSurface (screen) == 0)
   {
      Uint8 * pixels;
      pixels = (Uint8 *) screen->pixels;


      for (i = 0; i < screen->h; ++i)
      {
         memset (pixels, 0, screen->w * screen->format->BytesPerPixel);
         pixels += screen->pitch;
      }


      SDL_UnlockSurface (screen);
   }
}



static void word_area (pendu_screen * p_self, word_t * p_word)
{
   if (p_self != NULL && p_word != NULL)
   {
      if (p_self->word_need_update)
      {
         SDL_Color color = {GAME_TXT_R_VAL, GAME_TXT_G_VAL, GAME_TXT_B_VAL, 0};
         
         
         SDL_FreeSurface (p_self->p_word);

         switch (p_self->status)
         {
            case GAME_STATUS_IN_PROGRESS:
            case GAME_STATUS_GAINED:
            {
               p_self->p_word = make_text (
                  p_word->word, TABLE_FONT, WORD_FONT_SIZE, & color
               );
            }
            break;
 
            case GAME_STATUS_LOST:
            {
               p_self->p_word = make_text (
                  p_word->word_to_find, TABLE_FONT, WORD_FONT_SIZE, & color
               );
            }
            break;

            default:
               break;
         }


         if (p_self->p_word != NULL)
         {
            p_self->word_rect.w = p_self->p_word->w;
            p_self->word_rect.h = p_self->p_word->h;
            p_self->word_rect.x =
               (SCREEN_W / 2) - (p_self->p_word->w / 2);
            p_self->word_rect.y =
               p_self->p_screen->h - (BORDER_MARGIN + p_self->p_word->h);
         }

         p_self->word_need_update = SDL_TRUE;
      }
   }
}



static void top_infos_area (pendu_screen * p_self)
{
   if (p_self != NULL)
   {
      SDL_Color color = {INFO_TXT_R_VAL, INFO_TXT_G_VAL, INFO_TXT_B_VAL, 0};


      p_self->p_top_infos = make_text (
         SCREEN_TITLE, INFOS_FONT, INFO_TITLE_SIZE, & color
      );

      if (p_self->p_top_infos != NULL)
      {
         p_self->top_infos_rect.w = p_self->p_top_infos->w;
         p_self->top_infos_rect.h = p_self->p_top_infos->h;
         p_self->top_infos_rect.x = 
            (SCREEN_W / 2) - (p_self->p_top_infos->w / 2);
         p_self->top_infos_rect.y = 
            (BORDER_MARGIN / 2) - (p_self->p_top_infos->h / 2);
      }
   }
}



static void bottom_infos_area (pendu_screen * p_self)
{
   if (p_self != NULL && p_self->infos_need_update)
   {
      SDL_Color color = {INFO_TXT_R_VAL, INFO_TXT_G_VAL, INFO_TXT_B_VAL, 0};


      SDL_FreeSurface (p_self->p_bottom_infos);

      switch (p_self->infos_type)
      {
         case INFOS_TYPE_SINGLE:
         {
            p_self->p_bottom_infos = make_text (
               SINGLE_INFOS, INFOS_FONT, INFO_SIZE, & color
            );
         }
         break;

         case INFOS_TYPE_DOUBLE:
         {
            p_self->p_bottom_infos = make_text (
               DOUBLE_INFOS, INFOS_FONT, INFO_SIZE, & color
            );
         }
         break;

         default:
            break;
      }


      if (p_self->p_bottom_infos != NULL)
      {
         p_self->bottom_infos_rect.w = p_self->p_bottom_infos->w;
         p_self->bottom_infos_rect.h = p_self->p_bottom_infos->h;
         p_self->bottom_infos_rect.x = 
            (SCREEN_W / 2) - (p_self->p_bottom_infos->w / 2);
         p_self->bottom_infos_rect.y = 
            p_self->p_screen->h -
            (BORDER_MARGIN / 2);
      }


      p_self->infos_need_update = SDL_FALSE;
   }
}


static void hung_area (pendu_screen * p_self, int n)
{
   if (p_self != NULL && p_self->hung_need_update)
   {
      char filename [20];


      switch (p_self->status)
      {
         case GAME_STATUS_IN_PROGRESS:
         {
            sprintf (filename, HUNG_FILENAME, n);
         }
         break;

         case GAME_STATUS_GAINED:
         {
            sprintf (filename, GAINED_FILENAME);
         }
         break;

         case GAME_STATUS_LOST:
         {
            sprintf (filename, LOST_FILENAME);
         }
         break;

         default:
            break;
      }


      SDL_FreeSurface (p_self->p_hung);
      p_self->p_hung = IMG_Load (filename);

      if (p_self->p_hung != NULL)
      {
         p_self->hung_rect.w = p_self->p_hung->w;
         p_self->hung_rect.h = p_self->p_hung->h;
         p_self->hung_rect.x = (SCREEN_W / 2) - (p_self->p_hung->w / 2);
         p_self->hung_rect.y = BORDER_MARGIN;

         p_self->hung_need_update = SDL_FALSE;
      }
   }
}



pendu_screen * create_window (void)
{
   pendu_screen * p_self = malloc (sizeof (* p_self));

   if (p_self != NULL)
   {
      memset (p_self, 0, sizeof (p_self));

      p_self->p_screen = SDL_SetVideoMode (
         SCREEN_W, SCREEN_H, 16,
         SDL_SWSURFACE | SDL_DOUBLEBUF
      );

      if (p_self->p_screen != NULL)
      {
         SDL_WM_SetCaption (SCREEN_TITLE, NULL);

         p_self->screen_rect.w = p_self->p_screen->w;
         p_self->screen_rect.h = p_self->p_screen->h;
         p_self->screen_rect.x = 0;
         p_self->screen_rect.y = 0;

         p_self->type   = SCREEN_TYPE_GAME;
         p_self->status = GAME_STATUS_NEED_WORD;

         p_self->p_word          = NULL;
         p_self->p_hung          = NULL;
         p_self->p_top_infos     = NULL;
         p_self->p_bottom_infos  = NULL;

         p_self->screen_need_update = SDL_TRUE;
         p_self->word_need_update   = SDL_TRUE;
         p_self->hung_need_update   = SDL_FALSE;
         p_self->infos_need_update  = SDL_TRUE;

         p_self->infos_type = INFOS_TYPE_SINGLE;
         


         p_self->p_background = IMG_Load (BACKGROUND);

         if (p_self->p_background == NULL)
         {
            fprintf (stderr, "%s\n", SDL_GetError ());
         }



         top_infos_area    (p_self);
         bottom_infos_area (p_self);
      }
      else
      {

         destroy_window (& p_self);
      }
   }

   return p_self;
}



void destroy_window (pendu_screen ** p_self)
{
   if (p_self != NULL)
   {
      SDL_FreeSurface ((* p_self)->p_background);
      SDL_FreeSurface ((* p_self)->p_top_infos);
      SDL_FreeSurface ((* p_self)->p_bottom_infos);
      SDL_FreeSurface ((* p_self)->p_word);
      SDL_FreeSurface ((* p_self)->p_hung);

      free (* p_self);
      *p_self = NULL;
   }
}



void draw (pendu_screen * p_self, word_t * p_word)
{
   if (p_self != NULL)
   {
      clear_screen (p_self->p_screen);



      if (p_self->p_background != NULL)
      {
         SDL_BlitSurface (
            p_self->p_background, NULL,
            p_self->p_screen, & p_self->screen_rect
         );
      }



      if (p_self->p_top_infos != NULL)
      {
         SDL_BlitSurface (
            p_self->p_top_infos, NULL,
            p_self->p_screen, & p_self->top_infos_rect
         );
      }
      if (p_self->p_bottom_infos != NULL)
      {
         if (p_self->infos_need_update)
         {
            bottom_infos_area (p_self);
         }

         SDL_BlitSurface (
            p_self->p_bottom_infos, NULL,
            p_self->p_screen, & p_self->bottom_infos_rect
         );
      }



      word_area (p_self, p_word);

      if (p_self->p_word != NULL)
      {
         SDL_BlitSurface (
            p_self->p_word, NULL,
            p_self->p_screen, & p_self->word_rect
         );
      }



      if (p_word->nb_tests > 0 ||
          p_self->status == GAME_STATUS_GAINED ||
          p_self->status == GAME_STATUS_LOST)
      {
         hung_area (p_self, p_word->nb_tests);

         SDL_BlitSurface (
            p_self->p_hung, NULL,
            p_self->p_screen, & p_self->hung_rect
         );
      }


      SDL_Flip (p_self->p_screen);
   }
}

