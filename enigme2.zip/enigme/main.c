#include <stdio.h>
#include "SDL/SDL.h"
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include<SDL/SDL_ttf.h>
#include"enigme.h"


 int main(void) {
int directionSDL=0;
   int collision = 0;
  int game =0;


   SDL_Event event;
   SDL_Surface *screen=NULL;
  
SDL_Init(SDL_INIT_VIDEO);

screen = SDL_SetVideoMode(1200, 600, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);

SDL_FillRect(screen, 0, SDL_MapRGB(screen->format, 0,255, 255));
          functionenigme(screen);


SDL_Flip(screen);
SDL_EnableKeyRepeat(SDL_DEFAULT_REPEAT_DELAY,SDL_DEFAULT_REPEAT_INTERVAL);



SDL_Quit();
return 0;
}
